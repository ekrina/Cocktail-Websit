# UIDProj1
This is a UID project for a cocktail website where users learn simple cocktail recipes.
